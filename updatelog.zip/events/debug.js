module.exports = async (_Discord, _client, m) => {
	if (process.env.NODE_ENV === "development") console.log(m);
};
