module.exports = async (Discord, client, rateLimitInfo) => {
	console.log(rateLimitInfo);
};
