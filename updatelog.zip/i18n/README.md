# Suggester i18n
This repository servers as a database of all translated strings for the Suggester bot.
